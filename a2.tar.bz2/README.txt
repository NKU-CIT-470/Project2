client-ks.cfg
-----------------------------------------------
Used to setup new client machines.

	Power on a fresh system
	Within 10 seconds of booting hit esc
	Choose option 3 CD-ROM Drive
	Press tab
	Once done enter the command with the path to the kickstart file with the hostname
		linux ks=https://setupdocuments.sp.nku.edu/Documents/Group/client-ks.cfg hostname=<desired client hostname>
	Wait for the system to finish installation
	
	
install-ldap-server
-----------------------------------------------
Used to install and configure LDAP on the server

	If the server is not already booted on then go ahead and turn it on
	When shown the login prompt login as root
	Navigate to home directoy
		cd ~
	Use the wget command to download the package
		wget http://github.com/NKU-CIT-470/Project2/raw/main/a2.tar.bz2
	Type the following command to extract the files
		tar xvf a2.tar.bz2
	Switch to the a2 directory created when unziping the file
		cd a2
	Run the script
		./install-ldap-server
	
	
install-nfs-server
-----------------------------------------------
Used to install and configure NFS on the server

		If the server is not already booted on then go ahead and turn it on
	When shown the login prompt login as root
	Navigate to home directoy
		cd ~
	Use the wget command to download the package
		wget http://github.com/NKU-CIT-470/Project2/raw/main/a2.tar.bz2
	Type the following command to extract the files
		tar xvf a2.tar.bz2
	Switch to the a2 directory created when unziping the file
		cd a2
	Run the script
		./install-nfs-server
